package com.infy.semintegration.webservice;

public class Class1 {
    public Class1() {
        super();
    }
}
