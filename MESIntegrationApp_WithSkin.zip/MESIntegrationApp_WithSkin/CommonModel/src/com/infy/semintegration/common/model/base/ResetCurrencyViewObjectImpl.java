package com.infy.semintegration.common.model.base;

import oracle.jbo.Key;
import oracle.jbo.Row;
import oracle.jbo.server.TransactionEvent;
import oracle.jbo.server.ViewDefImpl;
import oracle.jbo.server.ViewObjectImpl;

public class ResetCurrencyViewObjectImpl extends ViewObjectImpl {
    private Key currentRowKey;
    private int firstRowInRange;
    private int currentRowIndexInRange;

    public ResetCurrencyViewObjectImpl() {
        super();
    }

    public ResetCurrencyViewObjectImpl(String string, ViewDefImpl viewDefImpl) {
        super(string, viewDefImpl);
    }
}
