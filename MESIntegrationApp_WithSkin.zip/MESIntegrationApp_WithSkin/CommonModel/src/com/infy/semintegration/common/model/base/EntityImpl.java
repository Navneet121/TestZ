package com.infy.semintegration.common.model.base;


public class EntityImpl extends oracle.jbo.server.EntityImpl {
    //private CustomADFLogger LOGGER = CustomADFLogger.createADFLogger(this.getClass());
//    private HashMap<String, Object> oldValueMap = new HashMap<String, Object>();
//    private HashMap<String, Object> newValueMap = new HashMap<String, Object>();
//    private HashMap columnNameMap = new HashMap();
//    private String operation;
//    private ArrayList<HashMap<String, Object>> auditList = new ArrayList<HashMap<String, Object>>();

    public EntityImpl() {
        super();
    }

}
