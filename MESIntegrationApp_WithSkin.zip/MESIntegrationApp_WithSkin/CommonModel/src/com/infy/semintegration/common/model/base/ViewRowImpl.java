package com.infy.semintegration.common.model.base;

import oracle.jbo.Row;

public class ViewRowImpl extends oracle.jbo.server.ViewRowImpl {
    public boolean rowSelected;
    
    public ViewRowImpl() {
        super();
    }



    public void setRowSelected(boolean rowSelected) {
        this.rowSelected = rowSelected;
    }

    public boolean isRowSelected() {
        return rowSelected;
    }
}
